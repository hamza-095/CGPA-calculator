package com.example.cgpa_calculator;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class GPAResultActivity extends AppCompatActivity {

    TextView gpaTextView, remarkTextView, quoteTextView;
    ProgressBar gpaProgressBar;
    Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gpa_result);

        // Link views
        gpaTextView = findViewById(R.id.gpaTextView);
        remarkTextView = findViewById(R.id.remarkTextView);
        quoteTextView = findViewById(R.id.quoteTextView);
        gpaProgressBar = findViewById(R.id.gpaProgressBar);
        backButton = findViewById(R.id.backButton);

        // Get GPA from Intent
        double gpa = getIntent().getDoubleExtra("calculated_gpa", -1);

        if (gpa >= 0) {
            gpaTextView.setText("GPA: " + String.format("%.2f", gpa));
            gpaProgressBar.setProgress((int) (gpa * 100));

            // Add remarks
            if (gpa > 3.7) {
                remarkTextView.setText("🎉 Excellent!");
            } else if (gpa >= 3.0) {
                remarkTextView.setText("👍 Good Job");
            } else {
                remarkTextView.setText("🧠 You can improve");
            }

            // Motivational quote
            quoteTextView.setText("“Keep learning. Keep growing.”");

        } else {
            gpaTextView.setText("GPA not available");
            remarkTextView.setText("");
            quoteTextView.setText("");
        }

        backButton.setOnClickListener(v -> finish());
    }
}
