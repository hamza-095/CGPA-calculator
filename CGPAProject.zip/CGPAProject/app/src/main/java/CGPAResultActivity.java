package com.example.cgpa_calculator;

import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CGPAResultActivity extends AppCompatActivity {

    TextView cgpaTextView, remarkTextView, quoteTextView;
    ProgressBar cgpaProgressBar;
    Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cgpa_result);

        // Link views
        cgpaTextView = findViewById(R.id.cgpaTextView);
        remarkTextView = findViewById(R.id.remarkTextView);
        quoteTextView = findViewById(R.id.quoteTextView);
        cgpaProgressBar = findViewById(R.id.cgpaProgressBar);
        backButton = findViewById(R.id.backButton);

        // Get CGPA from Intent
        double cgpa = getIntent().getDoubleExtra("calculated_cgpa", -1);

        if (cgpa >= 0) {
            cgpaTextView.setText("CGPA: " + String.format("%.2f", cgpa));

            // Animate progress
            int progressValue = (int) (cgpa * 100);
            ObjectAnimator.ofInt(cgpaProgressBar, "progress", 0, progressValue)
                    .setDuration(1000)
                    .start();

            // Add remarks
            if (cgpa >= 3.7) {
                remarkTextView.setText("🎉 Excellent!");
            } else if (cgpa >= 3.0) {
                remarkTextView.setText("👍 Good Job");
            } else {
                remarkTextView.setText("🧠 You can improve");
            }

            // Motivational quote
            quoteTextView.setText("“Keep learning. Keep growing.”");

        } else {
            cgpaTextView.setText("CGPA not available");
            remarkTextView.setText("");
            quoteTextView.setText("");
        }

        // Back button functionality
        backButton.setOnClickListener(v -> finish());
    }
}
