package com.example.cgpa_calculator;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Directly launch GetStartedActivity
        Intent intent = new Intent(MainActivity.this, GetStartedActivity.class);
        startActivity(intent);
        finish(); // Prevent user from returning to this screen
    }
}
