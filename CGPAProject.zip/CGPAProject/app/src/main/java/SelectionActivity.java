package com.example.cgpa_calculator;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class SelectionActivity extends AppCompatActivity {

    Button gpaButton, cgpaButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selection);

        gpaButton = findViewById(R.id.gpaButton);
        cgpaButton = findViewById(R.id.cgpaButton);

        gpaButton.setOnClickListener(v -> {
            Intent intent = new Intent(SelectionActivity.this, CourseDetailsActivity.class);
            startActivity(intent);
        });

        cgpaButton.setOnClickListener(v -> {
            Intent intent = new Intent(SelectionActivity.this, CGPAInputActivity.class);
            startActivity(intent);
        });
    }
}
