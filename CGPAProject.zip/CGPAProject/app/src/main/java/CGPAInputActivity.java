package com.example.cgpa_calculator;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CGPAInputActivity extends AppCompatActivity {

    EditText[] gpaInputs = new EditText[8];
    Button calculateCgpaButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cgpa_input);

        // Link all GPA EditText fields (gpa1 to gpa8)
        for (int i = 0; i < 8; i++) {
            int resId = getResources().getIdentifier("gpa" + (i + 1), "id", getPackageName());
            gpaInputs[i] = findViewById(resId);
        }

        // Link the calculate button
        calculateCgpaButton = findViewById(R.id.calculateCgpaButton);

        // Set up click listener
        calculateCgpaButton.setOnClickListener(v -> {
            double total = 0.0;
            int validSemesters = 0;

            for (int i = 0; i < 8; i++) {
                String input = gpaInputs[i].getText().toString().trim();

                if (!input.isEmpty()) {
                    try {
                        double gpa = Double.parseDouble(input);

                        if (gpa < 0.0 || gpa > 4.0) {
                            Toast.makeText(this, "Semester " + (i + 1) + " GPA must be between 0.0 and 4.0", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        total += gpa;
                        validSemesters++;

                    } catch (NumberFormatException e) {
                        Toast.makeText(this, "Invalid GPA in Semester " + (i + 1), Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
            }

            if (validSemesters == 0) {
                Toast.makeText(this, "Please enter at least one GPA", Toast.LENGTH_SHORT).show();
                return;
            }

            double finalCgpa = total / validSemesters;

            // Open the CGPA result screen
            Intent intent = new Intent(CGPAInputActivity.this, CGPAResultActivity.class);
            intent.putExtra("calculated_cgpa", finalCgpa);  // ✅ Correct key
            startActivity(intent);
        });
    }
}
