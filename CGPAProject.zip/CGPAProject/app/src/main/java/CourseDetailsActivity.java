package com.example.cgpa_calculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;

public class CourseDetailsActivity extends AppCompatActivity {

    EditText[] creditHours = new EditText[8];
    EditText[] grades = new EditText[8];
    Button calculateGpaBtn;
    HashMap<String, Double> gradeMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_details);

        // Link all EditTexts
        for (int i = 0; i < 8; i++) {
            int creditId = getResources().getIdentifier("creditHour" + (i + 1), "id", getPackageName());
            int gradeId = getResources().getIdentifier("grade" + (i + 1), "id", getPackageName());
            creditHours[i] = findViewById(creditId);
            grades[i] = findViewById(gradeId);
        }

        calculateGpaBtn = findViewById(R.id.calculateGpaBtn);
        setupGradeMap();

        calculateGpaBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateGPA();
            }
        });
    }

    private void setupGradeMap() {
        gradeMap = new HashMap<>();
        gradeMap.put("A", 4.0);
        gradeMap.put("A-", 3.7);
        gradeMap.put("B+", 3.3);
        gradeMap.put("B", 3.0);
        gradeMap.put("B-", 2.7);
        gradeMap.put("C+", 2.3);
        gradeMap.put("C", 2.0);
        gradeMap.put("C-", 1.7);
        gradeMap.put("F", 0.0);
    }

    private void calculateGPA() {
        double totalPoints = 0.0;
        int totalCredits = 0;

        for (int i = 0; i < 8; i++) {
            String creditText = creditHours[i].getText().toString().trim();
            String gradeText = grades[i].getText().toString().trim().toUpperCase();

            if (creditText.isEmpty() || gradeText.isEmpty()) {
                continue; // Skip empty fields
            }

            if (!gradeMap.containsKey(gradeText)) {
                Toast.makeText(this, "Invalid grade: " + gradeText, Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                int credit = Integer.parseInt(creditText);
                double gpa = gradeMap.get(gradeText);
                totalPoints += gpa * credit;
                totalCredits += credit;
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid credit hour in course " + (i + 1), Toast.LENGTH_SHORT).show();
                return;
            }
        }

        if (totalCredits == 0) {
            Toast.makeText(this, "Please enter at least one course.", Toast.LENGTH_SHORT).show();
            return;
        }

        double finalGpa = totalPoints / totalCredits;

        // Send GPA to GPAResultActivity with matching key
        Intent intent = new Intent(CourseDetailsActivity.this, GPAResultActivity.class);
        intent.putExtra("calculated_gpa", finalGpa);
        startActivity(intent);
    }
}
